# E-commerce Webstore
Simple product upload like Instagram, with margin and discount management.